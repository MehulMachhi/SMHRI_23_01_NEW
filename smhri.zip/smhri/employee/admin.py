from django.contrib import admin

# Register your models here.

from employee.models import EmployeeMaster


class EmployeeMasterAdmin(admin.ModelAdmin):
    list_display = ( 'company', 'first_name', 'aadhar_card_no',
                    )

    fieldsets = [
        ('Personal Info', {
            'fields': ['company', 'ticket_no', 'aadhar_card_no', 'name_pref'],
        }),
        ('Company Info', {
            'classes': ['collapse'],
            'fields': ['first_name', 'middle_name', 'last_name', 'father_name', 'mother_name', 'photo', 'pan_number'],
        }),
        ('About Of', {

            'fields': ['address', 'country', 'state', 'city', 'sex', 'birthdate', 'date_joining', 'designation'],
        }),
        ('Other', {
            'classes': ['collapse'],
            'fields': ['department', 'test_type', 'status', 'collection_date', 'test_date', 'fitness_certificate_date',
                       'previous_certificate_number', 'emp_added_date', ],
        }),
        ('AudiometerThresholdDecimats', {
            'classes': ['collapse'],
            'fields': ['audiometerThresholdDecimats'],
        }),
        ('BloodTest', {
            'classes': ['collapse'],
            'fields': ['bloodTest'],
        }),
        ('Complaints', {
            'classes': ['collapse'],
            'fields': ['complaints'],
        }),
        ('Hematology', {
            'classes': ['collapse'],
            'fields': ['hematology'],
        }),
        ('LungFunctionTest', {
            'classes': ['collapse'],
            'fields': ['lungFunctionTest'],
        }),
        ('MicroscopicExamination', {
            'classes': ['collapse'],
            'fields': ['microscopicExamination'],
        }),
        ('OtherTests', {
            'classes': ['collapse'],
            'fields': ['otherTests'],
        }),
        ('PhysiologicalTest', {
            'classes': ['collapse'],
            'fields': ['physiologicalTest'],
        }),
        ('SystematicExamination', {
            'classes': ['collapse'],
            'fields': ['systematicExamination'],
        }),
        ('VisualTest', {
            'classes': ['collapse'],
            'fields': ['visualTest'],
        }),
        ('TestMaster', {
            'classes': ['collapse'],
            'fields': ['testMaster'],
        }),

    ]

    # def has_module_permission(self, request):
    #     return False



admin.site.register(EmployeeMaster,EmployeeMasterAdmin)