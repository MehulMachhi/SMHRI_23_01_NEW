from django.shortcuts import render, redirect
from .models import EmployeeMaster
# Create your views here.

###################### ADD Employee Code ####################


def add_employees_data(request):
    if request.POST.get('company') and request.POST.get('ticket_no') and request.POST.get(
            'aadhar_card_no') and request.POST.get('name_pref') and request.POST.get('first_name')\
            and request.POST.get('middle_name')and request.POST.get('last_name')and request.POST.get('father_name')\
            and request.POST.get('mother_name')and request.POST.get('photo')and request.POST.get('pan_number')\
            and request.POST.get('address')and request.POST.get('country')and request.POST.get('state')\
            and request.POST.get('city')and request.POST.get('sex')and request.POST.get('birthdate')\
            and request.POST.get('date_joining')and request.POST.get('designation')and request.POST.get('middle_name')\
            and request.POST.get('middle_name')and request.POST.get('middle_name')and request.POST.get('middle_name')\
            and request.POST.get('middle_name')and request.POST.get('middle_name')and request.POST.get('middle_name'):

        app = EmployeeMaster()

        app.warehouse_name = request.POST.get('warehouse_name')
        app.warehouse_location = request.POST.get('warehouse_location')
        app.warehouse_contact = request.POST.get('warehouse_contact')
        app.warehouse_email = request.POST.get('warehouse_email')
        app.warehouse_manager = request.POST.get('warehouse_manager')
        app.save()
        warehouse = EmployeeMaster.objects.all()
        return render(request, 'view-employees.html', {'warehouse': warehouse})



    else:
        warehouse = EmployeeMaster.objects.all()
        return render(request, 'view-employees.html', {'warehouse': warehouse})

def add_employees_data(request):
    if request.method == "POST":
        post = EmployeeMaster()
        post.emp_id = request.POST.get('emp_id')
        post.company = request.POST.get('company')
        post.emp_no = request.POST.get('emp_no')
        post.ticket_no = request.POST.get('ticket_no')
        post.aadhar_card_no = request.POST.get('aadhar_card_no')
        post.name_prif = request.POST.get('name_prif')
        post.first_name = request.POST.get('first_name')
        post.middle_name = request.POST.get('middle_name')
        post.last_name = request.POST.get('last_name')
        post.father_name = request.POST.get('father_name')
        post.mother_name = request.POST.get('mother_name')
        post.photo = request.POST.get('photo')
        post.pan_number = request.POST.get('pan_number')
        post.address = request.POST.get('address')
        post.country = request.POST.get('country')
        post.state = request.POST.get('state')
        post.city = request.POST.get('city')
        post.sex = request.POST.get('sex')
        post.birthdate = request.POST.get('birthdate')
        post.date_joining = request.POST.get('date_joining')
        post.designation = request.POST.get('designation')
        post.department = request.POST.get('department')
        post.test_type = request.POST.get('test_type')
        post.status = request.POST.get('status')
        post.collection_date = request.POST.get('collection_date')
        post.test_date = request.POST.get('test_date')
        post.fitness_certificate_date = request.POST.get('fitness_certificate_date')
        post.previous_certificate_number = request.POST.get('previous_certificate_number')
        post.emp_added_date = request.POST.get('emp_added_date')
        post.audiometerThresholdDecimats = request.POST.get('audiometerThresholdDecimats')
        post.bloodTest = request.POST.get('bloodTest')
        post.complaints = request.POST.get('complaints')
        post.hematology = request.POST.get('hematology')
        post.lungFunctionTest = request.POST.get('lungFunctionTest')
        post.microscopicExamination = request.POST.get('microscopicExamination')
        post.otherTests = request.POST.get('otherTests')
        post.physiologicalTest = request.POST.get('physiologicalTest')
        post.systematicExamination = request.POST.get('systematicExamination')
        post.visualTest = request.POST.get('visualTest')
        post.testMaster = request.POST.get('testMaster')
        post.save()
        return render(request, 'view-employees.html')
    else:
        return render(request, 'view-employees.html')


###################### View Employee Code ####################

def view_employees_data(request):
    alldata = EmployeeMaster.objects.all()
    return render(request, 'view-employees.html', {"stu": alldata})

###################### UPDATE Employee Code ####################

def update_employees_data(request, id):
    update = EmployeeMaster.objects.get(id=id)
    update.save()
    return render(request, 'view-employees.html', {"edit": update})

def delete_employees_data(request, id):
    delete = EmployeeMaster.objects.get(id=id)
    delete.delete()
    return redirect('/')















