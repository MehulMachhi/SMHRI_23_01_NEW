from django.db import models
from test_master.models import (AudiometerThresholdDecimats, BloodTest, Complaints, Hematology
, LungFunctionTest, MicroscopicExamination, OtherTests, PhysiologicalTest, SystematicExamination, VisualTest,
                                TestMaster)

# Create your models here.

class EmployeeMaster(models.Model):
    company = models.CharField(max_length=20,blank=True, null=True)
    ticket_no = models.IntegerField(blank=True, null=True)
    aadhar_card_no = models.IntegerField(blank=True, null=True)
    # name_prif = models.CharField(max_length=4, blank=True, null=True)
    class name_pref(models.TextChoices):
        Mr = 'Mr.', ('Mr.')
        Mrs = 'Mrs.', ('Mrs.')
    name_pref = models.CharField(max_length=200,choices=name_pref.choices, blank=True)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    middle_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    father_name = models.CharField(max_length=100, blank=True, null=True)
    mother_name = models.CharField(max_length=100, blank=True, null=True)
    photo = models.ImageField(max_length=255, blank=True, null=True)
    pan_number = models.IntegerField(blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    country = models.CharField(max_length=255, blank=True, null=True)
    state = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=255, blank=True, null=True)

    class sex(models.TextChoices):
        Male = 'Male', ('male')
        Female = 'Female', ('female')
    sex = models.CharField(max_length=6, choices=sex.choices, blank=True, null=True)
    birthdate = models.DateField(blank=True, null=True)
    date_joining = models.DateField(blank=True, null=True)
    designation = models.CharField(max_length=200, blank=True, null=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    test_type = models.CharField(max_length=10, blank=True, null=True)
    class status(models.TextChoices):
        Approved = 'approved', ('approved')
        Pending = 'pending', ('pending')
    status = models.CharField(max_length=8, choices=status.choices, blank=True, null=True)
    collection_date = models.DateTimeField(blank=True, null=True)
    test_date = models.DateTimeField(blank=True, null=True)
    fitness_certificate_date = models.DateTimeField(blank=True, null=True)
    previous_certificate_number = models.IntegerField(blank=True, null=True)
    emp_added_date = models.DateTimeField()
    audiometerThresholdDecimats = models.ForeignKey(AudiometerThresholdDecimats, on_delete=models.CASCADE)
    bloodTest = models.ForeignKey(BloodTest, on_delete=models.CASCADE)
    complaints = models.ForeignKey(Complaints, on_delete=models.CASCADE)
    hematology = models.ForeignKey(Hematology, on_delete=models.CASCADE)
    lungFunctionTest = models.ForeignKey(LungFunctionTest, on_delete=models.CASCADE)
    microscopicExamination = models.ForeignKey(MicroscopicExamination, on_delete=models.CASCADE)
    otherTests = models.ForeignKey(OtherTests, on_delete=models.CASCADE)
    physiologicalTest = models.ForeignKey(PhysiologicalTest,  on_delete=models.CASCADE)
    systematicExamination = models.ForeignKey(SystematicExamination,  on_delete=models.CASCADE)
    visualTest = models.ForeignKey(VisualTest,  on_delete=models.CASCADE)
    testMaster = models.ForeignKey(TestMaster, on_delete=models.CASCADE)












































