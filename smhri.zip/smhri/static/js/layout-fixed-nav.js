(function($) {
    "use strict"

    new dezSettings({
        sidebarPosition: "fixed"
    });


})(jQuery);