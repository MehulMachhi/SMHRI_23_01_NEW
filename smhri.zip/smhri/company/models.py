from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
# Create your models here.

class CompanyMaster(models.Model):
    name = models.CharField(max_length=255)
    phone = models.IntegerField()
    email = models.EmailField(max_length=255)
    address = models.CharField(max_length=200, null=True)
    city = models.CharField(max_length=222,  null=True)
    company_type = models.CharField(max_length=222,  null=True)
    company_registration_certificate = models.ImageField(max_length=222,  null=True)

    def __str__(self):
        return self.name








