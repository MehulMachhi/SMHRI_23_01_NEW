from django.shortcuts import render, HttpResponse, redirect, HttpResponseRedirect
from .models import CompanyMaster

# Create your views here.

######################  INDEX PAGE ########################

def index(request):
    return render(request, 'index.html')

###################### Add Company Data ####################

# def add_company_data(request):
#     if request.method == 'POST':
#         name = request.POST.get('name')
#         phone = request.POST.get('phone')
#         email = request.POST.get('email')
#         address = request.POST.get('address')
#         print('mehul')
#         city = request.POST.get('city')
#         company_type = request.POST.get('company_type')
#         company_registration_certificate = request.POST.get('company_registration_certificate')
#         CompanyMaster.objects.create(name=name, phone=phone, email=email, address=address,
#                                            city=city, company_type=company_type, company_registration_certificate=company_registration_certificate)
#         company_master = CompanyMaster.objects.all()
#         return render(request, 'add-company.html', {'stu': company_master})
#     else:
#         company_master = CompanyMaster.objects.all()
#         return render(request, 'add-company.html', {'stu': company_master})

# def add_company_data(request):
#
#     if request.POST.get('name')  and request.POST.get('phone') and request.POST.get(
#                  'email') and request.POST.get('address') and request.POST.get('city') and request.POST.get(
#                  'company_type') and request.POST.get('company_registration_certificate'):
#                     app = CompanyMaster()
#                     app.name = request.POST.get('name')
#                     app.phone = request.POST.get('phone')
#                     app.email = request.POST.get('email')
#                     app.address = request.POST.get('address')
#                     app.city = request.POST.get('city')
#                     app.company_type = request.POST.get('company_type')
#                     app.company_registration_certificate = request.POST.get('company_registration_certificate'):
#
#                     app.name = request.POST.get('name')
#                     app.save()
#                     print('mehul')
#                     company_master = CompanyMaster.objects.all()
#                     return render(request, 'add-company.html', {'stu': company_master})
#     else:
#
#             company_master = CompanyMaster.objects.all()
#             return render(request, 'add-company.html', {'stu': company_master})


# def add_company_data(request):
#     if request.method == "POST":
#         print('zzz')
#         if request.POST.get('name') and request.POST.get('phone') and request.POST.get('email') and request.POST.get('address') and request.POST.get('city') and request.POST.get('company_type') and request.POST.get('company_registration_certificate'):
#
#             app = CompanyMaster()
#
#             app.name = request.POST.get('name')
#             app.phone = request.POST.get('phone')
#             app.email = request.POST.get('email')
#             app.address = request.POST.get('address')
#             app.city = request.POST.get('city')
#             app.company_type = request.POST.get('company_type')
#             app.company_registration_certificate = request.POST.get('company_registration_certificate')
#             app.save()
#             master = CompanyMaster.objects.all()
#             return render(request, 'add-company.html', {'stu': master})
#
#     else:
#
#         master = CompanyMaster.objects.all()
#         return render(request, 'add-company.html', {'stu': master})

def add_company_data(request):
    if request.method == "POST":
        print('mac')
        post = CompanyMaster()
        post.name = request.POST.get('name')
        post.phone = request.POST.get('phone')
        post.email = request.POST.get('email')
        post.address = request.POST.get('address')
        post.city = request.POST.get('city')
        post.company_type = request.POST.get('company_type')
        post.company_registration_certificate = request.POST.get('company_registration_certificate')
        post.save()
        alldata = CompanyMaster.objects.all()
        return render(request, 'view-companies.html',{"stu": alldata})
    else:
        return render(request, 'view-companies.html')

###################### GET Company Data ####################

def view_company_data(request):
    alldata = CompanyMaster.objects.all()
    return render(request, 'view-companies.html', {"stu": alldata})

###################### UPDATE Company Code ####################

def update_company_data(request, company_master_id):

    update = CompanyMaster.objects.get(id=company_master_id)
    update.save()
    return render(request, 'view-companies.html', {"edit": update})

###################### DELETE Company Code ####################

def delete_company_data(request):
    delete = CompanyMaster.objects.get(id=id)
    delete.delete()
    return redirect('/')


