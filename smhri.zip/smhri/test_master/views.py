from django.shortcuts import render, redirect


def get_test(request):
    return render(request, 'test.html')


# from .models import (AudiometerThresholdDecimats, BloodTest, Complaints, Hematology, LungFunctionTest,
#                      MicroscopicExamination, OtherTests, PhysiologicalTest, SystematicExamination, VisualTest, TestMaster)
#
#
#
# ######################################## AudiometerThresholdDecimats #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_audiometerthresholddecimats(request):
#     if request.method == "POST":
#         post = AudiometerThresholdDecimats()
#         post.audio_th_dec_id = request.POST.get('audio_th_dec_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.right_ac_500 = request.POST.get('right_ac_500')
#         post.right_bc_500 = request.POST.get('right_bc_500')
#         post.right_ac_1000 = request.POST.get('right_ac_1000')
#         post.right_bc_1000 = request.POST.get('right_bc_1000')
#         post.right_ac_2000 = request.POST.get('right_ac_2000')
#         post.right_bc_2000 = request.POST.get('right_bc_2000')
#         post.right_ac_4000 = request.POST.get('right_ac_4000')
#         post.right_bc_4000 = request.POST.get('right_bc_4000')
#         post.right_ac_5000 = request.POST.get('right_ac_5000')
#         post.right_bc_5000 = request.POST.get('right_bc_5000')
#         post.left_ac_500 = request.POST.get('left_ac_500')
#         post.left_bc_500 = request.POST.get('left_bc_500')
#         post.left_ac_1000 = request.POST.get('left_ac_1000')
#         post.left_bc_1000 = request.POST.get('left_bc_1000')
#         post.left_ac_2000 = request.POST.get('left_ac_2000')
#         post.left_bc_2000 = request.POST.get('left_bc_2000')
#         post.left_ac_4000 = request.POST.get('left_ac_4000')
#         post.left_bc_4000 = request.POST.get('left_bc_4000')
#         post.left_ac_5000 = request.POST.get('left_ac_5000')
#         post.left_bc_5000 = request.POST.get('left_bc_5000')
#         post.for_right_ear = request.POST.get('for_right_ear')
#         post.for_left_ear = request.POST.get('for_left_ear')
#         post.audiometery = request.POST.get('audiometery')
#         post.xray_report = request.POST.get('xray_report')
#         post.ultra_sonographic = request.POST.get('ultra_sonographic')
#         post.save()
#         return render(request, 'add-test-audiometerthresholddecimats.html')
#     else:
#         return render(request, 'add-test-audiometerthresholddecimats.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_audiometerthresholddecimats(request):
#     alldata = AudiometerThresholdDecimats.objects.all()
#     return render(request, 'view-test-audiometerthresholddecimats.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_audiometerthresholddecimats(request):
#     update = AudiometerThresholdDecimats.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-audiometerthresholddecimats.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_audiometerthresholddecimats(request):
#     delete = AudiometerThresholdDecimats.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## BloodTest #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_bloodtest(request):
#     if request.method == "POST":
#         post = BloodTest()
#         post.blood_test_id = request.POST.get('blood_test_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.blood_cholestrol = request.POST.get('blood_cholestrol')
#         post.s_creatinine = request.POST.get('s_creatinine')
#         post.blood_urea = request.POST.get('blood_urea')
#         post.fasting_blood_glucose = request.POST.get('fasting_blood_glucose')
#         post.random_blood_glucose = request.POST.get('random_blood_glucose')
#         post.post_prandial_blood_glucose = request.POST.get('post_prandial_blood_glucose')
#         post.total_bilirubin = request.POST.get('total_bilirubin')
#         post.direct_bilirubin = request.POST.get('direct_bilirubin')
#         post.indirect_bilirubin = request.POST.get('indirect_bilirubin')
#         post.sgpt = request.POST.get('sgpt')
#         post.sgot = request.POST.get('sgot')
#         post.alkaline_phosphatase = request.POST.get('alkaline_phosphatase')
#         post.ggt = request.POST.get('ggt')
#         post.total_cholesterol = request.POST.get('total_cholesterol')
#         post.triglycerides = request.POST.get('triglycerides')
#         post.direct_hdl = request.POST.get('direct_hdl')
#         post.vldl = request.POST.get('vldl')
#         post.ldl = request.POST.get('ldl')
#         post.ch_ratio = request.POST.get('ch_ratio')
#         post.lh_ratio = request.POST.get('lh_ratio')
#         post.rdw_sd = request.POST.get('rdw_sd')
#         post.plcc = request.POST.get('plcc')
#         post.plcr = request.POST.get('plcr')
#         post.vitaminb12 = request.POST.get('vitaminb12')
#         post.vitamind3 = request.POST.get('vitamind3')
#         post.hcv = request.POST.get('hcv')
#         post.psa = request.POST.get('psa')
#         post.bun = request.POST.get('bun')
#         post.save()
#         return render(request, 'add-test-bloodtest.html')
#     else:
#         return render(request, 'add-test-bloodtest.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_bloodtest(request):
#     alldata = BloodTest.objects.all()
#     return render(request, 'view-test-bloodtest.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_bloodtest(request):
#     update = BloodTest.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-bloodtest.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_bloodtest(request):
#     delete = BloodTest.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## Complaints #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_complaints(request):
#     if request.method == "POST":
#         post = Complaints()
#         post.complaint_id = request.POST.get('complaint_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.present_complaints = request.POST.get('present_complaints')
#         post.occupational_complaints = request.POST.get('occupational_complaints')
#         post.family_health_history = request.POST.get('family_health_history')
#         post.personal_health_history = request.POST.get('personal_health_history')
#         post.past_history = request.POST.get('past_history')
#         post.allergic_to = request.POST.get('allergic_to')
#         post.id_mark_scar = request.POST.get('id_mark_scar')
#         post.id_mark_mole = request.POST.get('id_mark_mole')
#         post.save()
#         return render(request, 'add-test-complaints.html')
#     else:
#         return render(request, 'add-test-complaints.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_complaints(request):
#     alldata = Complaints.objects.all()
#     return render(request, 'view-test-complaints.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_complaints(request):
#     update = Complaints.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-complaints.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_complaints(request):
#     delete = Complaints.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## Hematology #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_hematology(request):
#     if request.method == "POST":
#         post = Hematology()
#         post.hematology_id = request.POST.get('hematology_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.blood_group = request.POST.get('blood_group')
#         post.hemoglobin = request.POST.get('hemoglobin')
#         post.total_wbc_count = request.POST.get('total_wbc_count')
#         post.polymorphs = request.POST.get('polymorphs')
#         post.lymphocytes = request.POST.get('lymphocytes')
#         post.eosinophils = request.POST.get('eosinophils')
#         post.monocytes = request.POST.get('monocytes')
#         post.basophils = request.POST.get('basophils')
#         post.leucocytes_count = request.POST.get('leucocytes_count')
#         post.platelet_count = request.POST.get('platelet_count')
#         post.esr = request.POST.get('esr')
#         post.hct = request.POST.get('hct')
#         post.rdw_cv = request.POST.get('rdw_cv')
#         post.pdw = request.POST.get('pdw')
#         post.mpv = request.POST.get('mpv')
#         post.mch = request.POST.get('mch')
#         post.mchc = request.POST.get('mchc')
#         post.pct = request.POST.get('pct')
#         post.mcv = request.POST.get('mcv')
#         post.peripheral_smear = request.POST.get('peripheral_smear')
#         post.save()
#         return render(request, 'add-test-hematology.html')
#     else:
#         return render(request, 'add-test-hematology.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_hematology(request):
#     alldata = Hematology.objects.all()
#     return render(request, 'view-test-hematology.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_hematology(request):
#     update = Hematology.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-hematology.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_hematology(request):
#     delete = Hematology.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## LungFunctionTest #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_lungfunctiontest(request):
#     if request.method == "POST":
#         post = LungFunctionTest()
#         post.lung_function_test_id = request.POST.get('lung_function_test_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.fvc = request.POST.get('fvc')
#         post.fev1 = request.POST.get('fev1')
#         post.fev1_fvc = request.POST.get('fev1_fvc')
#         post.peak_exp_flow = request.POST.get('peak_exp_flow')
#         post.fef50 = request.POST.get('fef50')
#         post.fvc_predicted = request.POST.get('fvc_predicted')
#         post.fev1_predicted = request.POST.get('fev1_predicted')
#         post.fev1_fvc_predicted = request.POST.get('fev1_fvc_predicted')
#         post.pefr_predicted = request.POST.get('pefr_predicted')
#         post.fef50_predicted = request.POST.get('fef50_predicted')
#         post.fvc_per_predicted = request.POST.get('fvc_per_predicted')
#         post.fev1_per_predicted = request.POST.get('fev1_per_predicted')
#         post.fev1_fvc_per_predicted = request.POST.get('fev1_fvc_per_predicted')
#         post.pefr_per_predicted = request.POST.get('pefr_per_predicted')
#         post.fef50_per_predicted = request.POST.get('fef50_per_predicted')
#         post.spirometry = request.POST.get('spirometry')
#         post.save()
#         return render(request, 'add-test-lungfunctiontest.html')
#     else:
#         return render(request, 'add-test-lungfunctiontest.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_lungfunctiontest(request):
#     alldata = LungFunctionTest.objects.all()
#     return render(request, 'view-test-lungfunctiontest.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_lungfunctiontest(request):
#     update = LungFunctionTest.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-lungfunctiontest.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_lungfunctiontest(request):
#     delete = LungFunctionTest.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## MicroscopicExamination #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_microscopicexamination(request):
#     if request.method == "POST":
#         post = MicroscopicExamination()
#         post.micro_exam_id = request.POST.get('micro_exam_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.red_blood_cells = request.POST.get('red_blood_cells')
#         post.pus_cells = request.POST.get('pus_cells')
#         post.epithelial_cells = request.POST.get('epithelial_cells')
#         post.urine_report = request.POST.get('urine_report')
#         post.casts = request.POST.get('casts')
#         post.crystais = request.POST.get('crystais')
#         post.material = request.POST.get('material')
#         post.save()
#         return render(request, 'add-test-microscopicexamination.html')
#     else:
#         return render(request, 'add-test-microscopicexamination.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_microscopicexamination(request):
#     alldata = MicroscopicExamination.objects.all()
#     return render(request, 'view-test-microscopicexamination.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_microscopicexamination(request):
#     update = MicroscopicExamination.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-microscopicexamination.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_microscopicexamination(request):
#     delete = MicroscopicExamination.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## OtherTests #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_othertests(request):
#     if request.method == "POST":
#         post = OtherTests()
#         post.othertest_id = request.POST.get('othertest_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.serum_cholinesterase = request.POST.get('serum_cholinesterase')
#         post.hs_crp = request.POST.get('hs_crp')
#         post.gppd = request.POST.get('gppd')
#         post.hba1c = request.POST.get('hba1c')
#         post.avg_blood_glucose_level = request.POST.get('avg_blood_glucose_level')
#         post.hbsag = request.POST.get('hbsag')
#         post.hiv_result = request.POST.get('hiv_result')
#         post.hiv_method = request.POST.get('hiv_method')
#         post.hiv_remark = request.POST.get('hiv_remark')
#         post.s_protein_total = request.POST.get('s_protein_total')
#         post.s_albumin_bcg = request.POST.get('s_albumin_bcg')
#         post.s_globulin = request.POST.get('s_globulin')
#         post.ag_ratio = request.POST.get('ag_ratio')
#         post.acid_fast_bacilli = request.POST.get('acid_fast_bacilli')
#         post.stool_color = request.POST.get('stool_color')
#         post.stool_blood = request.POST.get('stool_blood')
#         post.stool_mucus = request.POST.get('stool_mucus')
#         post.stool_adults_warm = request.POST.get('stool_adults_warm')
#         post.stool_parasites = request.POST.get('stool_parasites')
#         post.stool_pus = request.POST.get('stool_pus')
#         post.stool_ph = request.POST.get('stool_ph')
#         post.stool_occult_blood = request.POST.get('stool_occult_blood')
#         post.stool_reducing_substances = request.POST.get('stool_reducing_substances')
#         post.stool_rbcs = request.POST.get('stool_rbcs')
#         post.stool_puscells = request.POST.get('stool_puscells')
#         post.stool_fat_globules = request.POST.get('stool_fat_globules')
#         post.stool_epithelial_cell = request.POST.get('stool_epithelial_cell')
#         post.stool_muscle_fibers = request.POST.get('stool_muscle_fibers')
#         post.stool_vegetable_cell = request.POST.get('stool_vegetable_cell')
#         post.stool_bacteria = request.POST.get('stool_bacteria')
#         post.stool_cyst = request.POST.get('stool_cyst')
#         post.stool_ova = request.POST.get('stool_ova')
#         post.stool_trophozoites = request.POST.get('stool_trophozoites')
#         post.stool_larva = request.POST.get('stool_larva')
#         post.stool_yeast_cells = request.POST.get('stool_yeast_cells')
#         post.stool_starch_granules = request.POST.get('stool_starch_granules')
#         post.thyroid_tsh = request.POST.get('thyroid_tsh')
#         post.thyroid_t3 = request.POST.get('thyroid_t3')
#         post.thyroid_t4 = request.POST.get('thyroid_t4')
#         post.vdrl = request.POST.get('vdrl')
#         post.save()
#         return render(request, 'add-test-othertests.html')
#     else:
#         return render(request, 'add-test-othertests.html')
#
#
# ###################### VIEW Report Code ####################
#
# def view_test_othertests(request):
#     alldata = OtherTests.objects.all()
#     return render(request, 'view-test-othertests.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_othertests(request):
#     update = OtherTests.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-othertests.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_othertests(request):
#     delete = OtherTests.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## PhysiologicalTest #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_physiologicaltest(request):
#     if request.method == "POST":
#         post = PhysiologicalTest()
#         post.phy_test_id = request.POST.get('phy_test_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.height = request.POST.get('height')
#         post.weight = request.POST.get('weight')
#         post.blood_pressure = request.POST.get('blood_pressure')
#         post.pulse = request.POST.get('pulse')
#         post.heart_sound = request.POST.get('heart_sound')
#         post.chest_on_expiration = request.POST.get('chest_on_expiration')
#         post.chest_on_inspiration = request.POST.get('chest_on_inspiration')
#         post.waist = request.POST.get('waist')
#         post.hips = request.POST.get('hips')
#         post.waist_hip_ratio = request.POST.get('waist_hip_ratio')
#         post.remarks_and_advice = request.POST.get('remarks_and_advice')
#         post.save()
#         return render(request, 'add-test-physiologicaltest.html')
#     else:
#         return render(request, 'add-test-physiologicaltest.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_physiologicaltest(request):
#     alldata = PhysiologicalTest.objects.all()
#     return render(request, 'view-test-physiologicaltest.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_physiologicaltest(request):
#     update = PhysiologicalTest.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-physiologicaltest.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_physiologicaltest(request):
#     delete = PhysiologicalTest.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## SystematicExamination #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_systematicexamination(request):
#     if request.method == "POST":
#         post = SystematicExamination()
#         post.sys_exm_id = request.POST.get('sys_exm_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.skin = request.POST.get('skin')
#         post.respiratory_system = request.POST.get('respiratory_system')
#         post.cardiovascular_system = request.POST.get('cardiovascular_system')
#         post.genito_urinary_system = request.POST.get('genito_urinary_system')
#         post.skeletal_system = request.POST.get('skeletal_system')
#         post.cns = request.POST.get('cns')
#         post.breath_sound = request.POST.get('breath_sound')
#         post.abdomen = request.POST.get('abdomen')
#         post.other_finding = request.POST.get('other_finding')
#         post.ecg_report = request.POST.get('ecg_report')
#         post.save()
#         return render(request, 'add-test-systematicexamination.html')
#     else:
#         return render(request, 'add-test-systematicexamination.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_systematicexamination(request):
#     alldata = SystematicExamination.objects.all()
#     return render(request, 'view-test-systematicexamination.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_systematicexamination(request):
#     update = SystematicExamination.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-systematicexamination.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_systematicexamination(request):
#     delete = SystematicExamination.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## VisualTest #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_visualtest(request):
#     if request.method == "POST":
#         post = VisualTest()
#         post.visual_test_id = request.POST.get('visual_test_id')
#         post.emp_id = request.POST.get('emp_id')
#         post.nearvision_without_glass = request.POST.get('nearvision_without_glass')
#         post.distance_vision_without_glass = request.POST.get('distance_vision_without_glass')
#         post.nearvision_with_glass = request.POST.get('nearvision_with_glass')
#         post.distance_vision_with_glass = request.POST.get('distance_vision_with_glass')
#         post.nearvision_without_glass_right = request.POST.get('nearvision_without_glass_right')
#         post.distance_vision_without_glass_right = request.POST.get('distance_vision_without_glass_right')
#         post.nearvision_with_glass_right = request.POST.get('nearvision_with_glass_right')
#         post.distance_vision_with_glass_right = request.POST.get('distance_vision_with_glass_right')
#         post.vision_remark = request.POST.get('vision_remark')
#         post.save()
#         return render(request, 'add-test-visualtest.html')
#     else:
#         return render(request, 'add-test-visualtest.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_visualtest(request):
#     alldata = VisualTest.objects.all()
#     return render(request, 'view-test-visualtest.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_visualtest(request):
#     update = VisualTest.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-visualtest.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_visualtest(request):
#     delete = VisualTest.objects.get(id=id)
#     delete.delete()
#     return redirect('/')
#
#
# ######################################## TestMaster #########################################
#
# ###################### ADD Test Code ####################
#
# def add_test_testmaster(request):
#     if request.method == "POST":
#         post = TestMaster()
#         post.test_id = request.POST.get('test_id')
#         post.test_name = request.POST.get('test_name')
#         post.test_desc = request.POST.get('test_desc')
#         post.status = request.POST.get('status')
#         post.test_model = request.POST.get('test_model')
#         post.save()
#         return render(request, 'add-test-testmaster.html')
#     else:
#         return render(request, 'add-test-testmaster.html')
#
# ###################### VIEW Report Code ####################
#
# def view_test_testmaster(request):
#     alldata = TestMaster.objects.all()
#     return render(request, 'view-test-testmaster.html', {'stu', alldata})
#
# ###################### UPDATE Report Code ####################
#
# def update_test_testmaster(request):
#     update = TestMaster.objects.get(id=id)
#     update.save()
#     return render(request, 'view-test-testmaster.html', {"edit": update})
#
# ###################### DELETE Report Code ####################
#
# def delete_test_testmaster(request):
#     delete = TestMaster.objects.get(id=id)
#     delete.delete()
#     return redirect('/')




















